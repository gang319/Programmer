package minigame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import minigame.vo.Member;

public class Member_Database {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setConn() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		con = DriverManager.getConnection(url,"scott","tiger");
		System.out.println("오라클 접속 성공");
	}
	
	public ArrayList<Member> getMemberList() {
		ArrayList<Member> mlist = new ArrayList<Member>();
		
		try {
			setConn();
			
			String sql = "SELECT * FROM MEMBER";
			
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 1;
			
			Member mem = null;
			
			while(rs.next()) {
				mem = new Member(
						rs.getString("id"),
						rs.getString("pass"),
						rs.getString("mname"),
						rs.getInt("point")
						);
				
				mlist.add(mem);
				
				System.out.print((cnt++)+"번째 행\t"+rs.getString("id")+"\t");
				System.out.print(rs.getString("pass")+"\t");
				System.out.print(rs.getString("mname")+"\t");
				System.out.print(rs.getInt("point")+"\n");
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return mlist;
	}
	
	public void insertMember(Member ins) {
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "INSERT INTO MEMBER VALUES(upper(?),upper(?),upper(?),0)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, ins.getId());
			pstmt.setString(2, ins.getPass());
			pstmt.setString(3, ins.getMname());
			
			pstmt.executeUpdate();
			
			con.commit();
			
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		System.out.println("회원 등록 성공");
	}
	
	
	
		///////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////내 포인트 검색////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////
	public int getPo(String id) {
		int toprank = 0;

		try {
			setConn();

			String sql = "select point from member where upper(id) = upper(?) ";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
			toprank = rs.getInt(1);
			}
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} 
		finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return toprank;
	}


	public Member login(Member m) {
		Member logMem = null;
		
		try {
			setConn();
			
			String sql ="SELECT *\r\n" + 
					"FROM MEMBER\r\n" + 
					"WHERE UPPER(id) = UPPER(?)  \r\n" + 
					"AND UPPER(pass) =  UPPER(?)  ";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, m.getId());
			pstmt.setString(2, m.getPass());
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				logMem = new Member (
						rs.getString("id"),
						rs.getString("pass"),
						rs.getString("mname"),
						rs.getInt("point")
						);
			}
			
			rs.close();
			pstmt.close();
			con.close();
					
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			// 해제되지 않는 자원이 해제 이중 체크
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return logMem;
	}
	
	public String idchk(String id) {
		String chkid=null;
		try {
			setConn();
			
			String sql ="SELECT upper(id)\r\n" + 
					"FROM MEMBER\r\n" + 
					"WHERE upper(id)=upper(?)";
			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				chkid = rs.getString(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
					
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			// 해제되지 않는 자원이 해제 이중 체크
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return chkid;
	}

	public static void main(String[] args) { 
		Member_Database db = new Member_Database();
		db.getMemberList();
		
		Member m = new Member("goGil","dooli22");
		
		
		System.out.println(db.idchk("em"));
		
		
	}
}
