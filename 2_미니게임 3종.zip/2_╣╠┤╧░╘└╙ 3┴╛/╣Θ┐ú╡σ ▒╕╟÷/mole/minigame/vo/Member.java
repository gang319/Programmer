package minigame.vo;

public class Member {
	private String id;
	private String pass;
	private String mname;
	private int point;
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Member(String id, String pass) {
		super();
		this.id = id;
		this.pass = pass;
	}


	public Member(String id, String pass, String mname, int point) {
		super();
		this.id = id;
		this.pass = pass;
		this.mname = mname;
		this.point = point;
	}

	
	public Member(String id) {
		super();
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}
	

}
