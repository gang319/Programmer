package minigame.vo;

public class Own {
	private String id;
	private int amt_t;
	private int amt_h;
	private int amt_c;	
	
	public Own() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Own(String id) {
		super();
		this.id = id;
	}

	public Own(String id, int amt_t, int amt_h, int amt_c) {
		super();
		this.id = id;
		this.amt_t = amt_t;
		this.amt_h = amt_h;
		this.amt_c = amt_c;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAmt_t() {
		return amt_t;
	}

	public void setAmt_t(int amt_t) {
		this.amt_t = amt_t;
	}

	public int getAmt_h() {
		return amt_h;
	}

	public void setAmt_h(int amt_h) {
		this.amt_h = amt_h;
	}

	public int getAmt_c() {
		return amt_c;
	}

	public void setAmt_c(int amt_c) {
		this.amt_c = amt_c;
	}	
}