package minigame.vo;

public class Itemshop {
	private String iname;
	private String effect;
	private int point;
	
	public Itemshop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Itemshop(String iname, String effect, int point) {
		super();
		this.iname = iname;
		this.effect = effect;
		this.point = point;
	}
	
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getEffect() {
		return effect;
	}
	public void setEffect(String effect) {
		this.effect = effect;
	}
	public int getPoint() {
		return point;
	}
	public void setPoint(int point) {
		this.point = point;
	}	
}