package minigame.vo;

public class Rank {
	private String id;
	private String gname;
	private int score;
	
	public Rank() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Rank(String id) {
		super();
		this.id = id;
	}

	public Rank(String gname, int score) {
		super();
		this.gname = gname;
		this.score = score;
	}

	public Rank(String id, String gname, int score) {
		super();
		this.id = id;
		this.gname = gname;
		this.score = score;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGname() {
		return gname;
	}

	public void setGname(String gname) {
		this.gname = gname;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	
	
}
