package minigame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import minigame.vo.Member;
import minigame.vo.Rank;

public class Rank_Database {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setConn() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		con = DriverManager.getConnection(url,"scott","tiger");
		System.out.println("오라클 접속 성공");
	}
	
	public ArrayList<Rank> getRank() {
		ArrayList<Rank> rlist = new ArrayList<Rank>();
		
		try {
			setConn();
			
			String sql ="SELECT * \r\n" + 
					"FROM RANK \r\n" + 
					"WHERE rownum<=10 AND gname='두더지 팡팡' \r\n" + 
					"ORDER BY score DESC";
			
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 1;
			
			Rank rank = null;
			
			while(rs.next()) {
				rank = new Rank(
						rs.getString("id"),
						rs.getString("gname"),
						rs.getInt("score")
						);
				
				rlist.add(rank);
				
				System.out.print((cnt++)+"번째 행\t"+rs.getString("id")+"\t");
				System.out.print(rs.getString("gname")+"\t");
				System.out.print(rs.getInt("score")+"\n");
			} 
			
			rs.close();
			pstmt.close();
			con.close();
			
		}
			
			catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return rlist;
	}
	
	public void insertScore(Rank ins) {
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "INSERT INTO RANK VALUES(upper(?),?,?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, ins.getId());
			pstmt.setString(2, ins.getGname());
			pstmt.setInt(3, ins.getScore());
			
			pstmt.executeUpdate();
			
			con.commit();
			
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		System.out.println("점수 등록 성공");
	}
	
	public int highRank(String gname) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select max(score) from rank where gname = ?";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, gname);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}
	
	public int highAvoid(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select max(score) from rank where gname = '살아남아라 베슬' and upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}
	


	

	public ArrayList<Rank> getRanka() {
		ArrayList<Rank> rlist = new ArrayList<Rank>();
		
		try {
			setConn();
			
			String sql ="SELECT * \r\n" + 
					"FROM RANK \r\n" + 
					"WHERE rownum<=10 AND gname='살아남아라 베슬' \r\n" + 
					"ORDER BY score DESC";
			
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 1;
			
			Rank rank = null;
			
			while(rs.next()) {
				rank = new Rank(
						rs.getString("id"),
						rs.getString("gname"),
						rs.getInt("score")
						);
				
				rlist.add(rank);
				
				System.out.print((cnt++)+"번째 행\t"+rs.getString("id")+"\t");
				System.out.print(rs.getString("gname")+"\t");
				System.out.print(rs.getInt("score")+"\n");
			} 
			
			rs.close();
			pstmt.close();
			con.close();
			
		}
			
			catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return rlist;
	}
	
	public ArrayList<Rank> getRankg() {
		ArrayList<Rank> rlist = new ArrayList<Rank>();
		
		try {
			setConn();
			
			String sql ="SELECT * \r\n" + 
					"FROM RANK \r\n" + 
					"WHERE rownum<=10 AND gname='팡야' \r\n" + 
					"ORDER BY score DESC";
			
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 1;
			
			Rank rank = null;
			
			while(rs.next()) {
				rank = new Rank(
						rs.getString("id"),
						rs.getString("gname"),
						rs.getInt("score")
						);
				
				rlist.add(rank);
				
				System.out.print((cnt++)+"번째 행\t"+rs.getString("id")+"\t");
				System.out.print(rs.getString("gname")+"\t");
				System.out.print(rs.getInt("score")+"\n");
			} 
			
			rs.close();
			pstmt.close();
			con.close();
			
		}
			
			catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return rlist;
	}


	public int highMole(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select max(score) from rank where gname = '두더지 팡팡' and upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}

	public int highGolf(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select max(score) from rank where gname = '팡야' and upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Rank_Database db = new Rank_Database();	
		System.out.println("Gogil님의 두더지 팡팡 최고점수 : "+db.highMole("gogil"));
		System.out.println("Gogil님의 살아남아라 베슬 최고점수 : "+db.highAvoid("gogil"));
		System.out.println("Gogil님의 팡야 최고점수 : "+db.highGolf("gogil"));
	}

}
