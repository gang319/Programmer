package minigame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import minigame.vo.Member;
import minigame.vo.Rank;
import minigame.vo.Own;

public class Own_Database {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public void setConn() throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		con = DriverManager.getConnection(url,"scott","tiger");
		System.out.println("오라클 접속 성공");
	}
	
	public ArrayList<Own> getOwn() {
		ArrayList<Own> rlist = new ArrayList<Own>();
		
		try {
			setConn();
			
			String sql ="SELECT * FROM OWN";
			
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 1;
			
			Own own = null;
			
			while(rs.next()) {
				own = new Own(
						rs.getString("id"),
						rs.getInt("amt_t"),
						rs.getInt("amt_h"),
						rs.getInt("amt_c")						
						);
				
				rlist.add(own);
				
				System.out.print((cnt++)+"번째 행\t"+rs.getString("id")+"\t");
				System.out.print(rs.getInt("amt_t")+"\t");
				System.out.print(rs.getInt("amt_h")+"\n");
				System.out.print(rs.getInt("amt_c")+"\n");
			} 
			
			rs.close();
			pstmt.close();
			con.close();
			
		}
			
			catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			if(rs!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(pstmt!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return rlist;
	}
	
	public void insertOwn(Own ins) {
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "INSERT INTO OWN VALUES(?,?,?,?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, ins.getId());
			pstmt.setInt(2, ins.getAmt_t());
			pstmt.setInt(3, ins.getAmt_h());
			pstmt.setInt(4, ins.getAmt_c());
			
			pstmt.executeUpdate();
			
			con.commit();
			
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		System.out.println("아이템 등록 성공");
	}
	
	public int hammer(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select AMT_T from OWN where upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}
	

	public int defense(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select AMT_H from OWN where upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}
	
	
	public int calm(String id) {
		int toprank = 0;
		
		try {
			setConn();
			
			con.setAutoCommit(false);
			
			String sql = "select AMT_C from OWN where upper(id) = upper(?)";
			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, id);			;
			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				toprank=rs.getInt(1);
			}
			
			rs.close();
			pstmt.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
			try {
				con.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				System.out.println("롤백예외 발생");
			}
		} finally {
			if(pstmt!=null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return toprank;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Own_Database db = new Own_Database();
		
	
		System.out.println(db.hammer("gogil"));
		
	}

}
