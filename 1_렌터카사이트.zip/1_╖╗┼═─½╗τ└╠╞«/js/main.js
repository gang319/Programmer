$(function(){
    
    var list=$("#book_frame");
    var num=0;
    var li_width=1003;
    
    $(".next").click(function(){
        if(num>=1) return false;
        
        num++;
        list.stop().animate({marginLeft:-num*li_width+"px"},300);

    });
    
})