package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Search;
import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;

@Repository
public interface ProjectDao {
	public int getCount(Search sch);
	
	public ArrayList<Project> plist(Search sch);
	
	public Project getProject(String pro_co);

	public void insertProject(Project insert);
	
	public ArrayList<Task> getProTask(String pro_co);
	
	public void updateProject(Project upt);
	
	public void deleteProject(Project del);
	
}


