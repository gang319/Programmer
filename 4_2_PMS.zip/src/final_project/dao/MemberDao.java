package final_project.dao;

import org.springframework.stereotype.Repository;

import final_project.vo.Member;

@Repository
public interface MemberDao {
	public Member memlogin(Member m);

}
