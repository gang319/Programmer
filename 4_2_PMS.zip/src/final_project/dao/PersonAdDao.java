package final_project.dao;
//final_project.dao.PersonAdDao
import org.springframework.stereotype.Repository;

import final_project.vo.Member;


@Repository
public interface PersonAdDao {
	/*조회*/
	public Member adperson(Member m);
}
