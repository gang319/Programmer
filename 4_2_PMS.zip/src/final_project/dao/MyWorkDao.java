package final_project.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;

@Repository
public interface MyWorkDao {
	public ArrayList<Project> getProject(Project sch);
	
	public ArrayList<Task> getTask(Task sch);
	
	public ArrayList<Issue> getIssue(Issue sch);
	
	
}
