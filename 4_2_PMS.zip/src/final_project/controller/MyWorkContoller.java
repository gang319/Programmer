package final_project.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import final_project.service.MyWorkService;
import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;

@Controller
@RequestMapping("/mywork.do")
public class MyWorkContoller {
	@Autowired
	private MyWorkService service;
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    dateFormat.setLenient(false);

	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@RequestMapping(params = "method=main")
	public String main(Project p, Task t, Issue i, Model m) {
		System.out.println("프로젝트 타이틀: " + p.getPro_title());
		System.out.println("업무명: " + t.getTask_name());
		System.out.println("이슈명: " + i.getTitle());
		
		m.addAttribute("myproject", service.getProject(p));
		m.addAttribute("mytask", service.getTask(t));
		m.addAttribute("myissue", service.getIssue(i));
		
		return "WEB-INF\\view\\bs\\myWork.jsp";
	}

}
