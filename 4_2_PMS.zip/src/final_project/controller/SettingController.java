package final_project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.SettingService;
import final_project.vo.Member;

//http://localhost:7080/final_project/pmsset.do?method=person
//http://localhost:7080/final_project/pmsset.do?method=detail
//http://localhost:7080/a03_team/pmsset.do?method=person
//http://localhost:7080/a03_team/issue.do?method=list
@Controller
@RequestMapping("/pmsset.do")
public class SettingController {
	@Autowired
	private SettingService service;
	
	//담당자 고객 리스트
	@RequestMapping(params = "method=person")
	public String setpm(Model d) {
		d.addAttribute("elist",service.elist());		
		d.addAttribute("clist",service.clist());
		
		return "WEB-INF\\view\\bs\\setting.jsp";		
	}
	
	//담당자 입력 insert
	@RequestMapping(params="method=insert")
	public String insert(Member insert,Model d)throws Exception{
		System.out.println("등록:"+insert.getId());		
		service.insertMember(insert);
		Member m = new Member();
		d.addAttribute("member",m);
		
		System.out.println("id: " + insert.getId());
		
		return "pageJsonReport";
	}
	
	//담당자 수정 detail
	@RequestMapping(params="method=detail")
	public String detail(@RequestParam("id")String id,Model d) throws Exception{
		System.out.println("아이디: "+id);
		
		d.addAttribute("member",service.getMember(id));		
		return "pageJsonReport";
	}
	
	//담당자 수정 update
	@RequestMapping(params="method=update")
	public String update(Member upt,Model d) throws Exception {
		service.updateMember(upt);		
		d.addAttribute("member",service.getMember(upt.getId()));
		
		return "pageJsonReport";
	}
	
	//담당자 삭제 delete
	@RequestMapping(params="method=delete")
	public String delete(@RequestParam("id") String id,Model d) throws Exception {
		service.delMember(id);
		Member m = new Member();
		m.setId("삭제성공");
		d.addAttribute("member",m);
		
		return "pageJsonReport";
	}
	
	//ADMIN 권한설정 update
	@RequestMapping(params="method=adupdate")
	public String adMember(Member ad,Model d)throws Exception{
		service.adMember(ad);
		d.addAttribute("member",service.getMember(ad.getId()));
		
		return "pageJsonReport";
	}
	
	//PM 권한설정 update
	@RequestMapping(params="method=pmupdate")
	public String pmMember(Member pm,Model d)throws Exception{
		service.pmMember(pm);
		d.addAttribute(pm);
		d.addAttribute("member",service.getMember(pm.getId()));
		
		return "pageJsonReport";		
	}
	
	//
	
	
}