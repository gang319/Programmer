package final_project.controller;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.ProjectService;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;

@Controller
@RequestMapping("/pmsPro.do")
public class ProjectController {
	@InitBinder
	public void initBinder(WebDataBinder binder) throws Exception {
	    binder.registerCustomEditor(Date.class, new PropertyEditorSupport() {

	        public void setAsText(String text) throws IllegalArgumentException {
	            try {
	                setValue(new SimpleDateFormat("yyyy-MM-dd").parse(text));
	            } catch (ParseException e) {
	                setValue(null);
	            }
	        }
	    });
	}
	
	@Autowired
	private ProjectService service;
	
	@RequestMapping(params = "method=project")
	public String project(@ModelAttribute("psch") Search sch, Model d) {
		d.addAttribute("plist", service.plist(sch));
		
		return "WEB-INF\\view\\bs\\projectList.jsp";		
	}
	
	@RequestMapping(params="method=proDetail")
	public String proDetail(@RequestParam("pro_co") String pro_co, Model d) throws Exception {
		System.out.println("선택 pro_co"+pro_co);
		d.addAttribute("project", service.getProject(pro_co));
		
		return "pageJsonReport";
	}
	
	// 프로젝트 추가
	@RequestMapping(params ="method=proinsert")
	public String insert(Project p, Model d) throws Exception{
		System.out.println("등록: "+p.getPro_title());
		service.insertProject(p);
		d.addAttribute("succ", "insert");
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params ="method=proupdate")
	public String update(Project p, Model d) throws Exception{
		System.out.println("수정: "+p.getPro_title());
		service.updateProject(p);
		d.addAttribute("succ", "update");
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params ="method=prodelete")
	public String delete(Project p, Model d) throws Exception{
		System.out.println("삭제: "+p.getPro_title());
		service.deleteProject(p);
		d.addAttribute("succ", "delete");
		
		return "pageJsonReport";
	}
	
	// 프로젝트 리스트 더블 클릭 시 관련 업무 리스트 나열
	@RequestMapping(params="method=protaskList")
	public String protaskList(@RequestParam("pro_co") String pro_co, Model d) throws Exception {
		System.out.println("선택 pro_co: " + pro_co);
		d.addAttribute("protask", service.getProTask(pro_co));
		d.addAttribute("getPro", service.getProject(pro_co));
		
		return "WEB-INF\\view\\bs\\protaskList.jsp";
	}
	
}
