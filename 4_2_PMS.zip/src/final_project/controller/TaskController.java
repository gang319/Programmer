package final_project.controller;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import final_project.service.TaskService;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;

@Controller
@RequestMapping("/pmsTask.do")
public class TaskController {
	@InitBinder
	public void initBinder(WebDataBinder binder) throws Exception {
	    binder.registerCustomEditor(Date.class, new PropertyEditorSupport() {

	        public void setAsText(String text) throws IllegalArgumentException {
	            try {
	                setValue(new SimpleDateFormat("yyyy-MM-dd").parse(text));
	            } catch (ParseException e) {
	                setValue(null);
	            }
	        }
	    });
	}
	@Autowired
	private TaskService service;
	
	@RequestMapping(params = "method=task")
	public String task(@ModelAttribute("tsch") Search sch, Model d) {
		d.addAttribute("tlist", service.tlist(sch));
		d.addAttribute("getProject", service.getProject());
		
		return "WEB-INF\\view\\bs\\taskList.jsp";
	}
	
	@RequestMapping(params = "method=protask")
	public String protask(Task t, Model d) {
		d.addAttribute("ptlist", service.ptlist());
		return "WEB-INF\\view\\bs\\protaskList.jsp";
	}
	
	@RequestMapping(params="method=detail")
	public String detail(@RequestParam("task_co") String task_co, Model d) throws Exception  {
		System.out.println("검색 task_co: " + task_co);
		d.addAttribute("task", service.getTask(task_co));
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=taskinsert")
	public String insert(Task t, Model d) throws Exception{
		System.out.println("업무 등록: "+t.getTask_name());
		service.insertTask(t);
		d.addAttribute("succ", "insert");
		
		return "pageJsonReport";
	}
	
	@RequestMapping(params="method=taskupdate")
	public String update(Task upt, Model d) throws Exception{
		System.out.println("업무코드: " + upt.getTask_co());
		System.out.println("프로젝트명: " + upt.getPro_title());
		System.out.println("이름: " + upt.getName());
		System.out.println("우선순위: " + upt.getTask_rank());
		System.out.println("업무명: " + upt.getTask_name());
		System.out.println("분류: " + upt.getSort());
		System.out.println("프로세스: " + upt.getPro_state());
		System.out.println("프로세스순서: " + upt.getPro_statenum());
		System.out.println("난이도: " + upt.getDifficulty());
		System.out.println("시작일: " + upt.getTask_sdate());
		System.out.println("마김일: " + upt.getDeadline());
		
		service.updateTask(upt);
		d.addAttribute("succ", "update");
		
		return "pageJsonReport";
	}
}
