package final_project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.TaskDao;
import final_project.vo.Project;
import final_project.vo.Search;
import final_project.vo.Task;

@Service
public class TaskService {
	@Autowired
	private TaskDao dao;
	
	public ArrayList<Task> tlist(Search sch){
		// 데이터 총 건수 처리
		sch.setCount(dao.getCount(sch));
						
		// 화면에 한번에 보여줄 데이터 수 
		if(sch.getPageSize() == 0) { sch.setPageSize(10); }
						
		// 총 페이지 수 처리
		int pgCnt = (int)Math.ceil(sch.getCount() / (double)sch.getPageSize());
		sch.setPageCount(pgCnt == 0 ? 1 : pgCnt);
						
		// 현재 클릭한 페이지 수 설정, 초기값 1
		if(sch.getCurPage() == 0) { sch.setCurPage(1); }
						
		// next 클릭시, 전체 페이지 수를 넘지 않게 처리
		if(sch.getCurPage() > sch.getPageCount()) {
			sch.setCurPage(sch.getPageCount()); 
		}
						
		// 현재 클릭한 페이지 번호를 통해서 시작 번호와 마지막 번호를 전송처리 
		sch.setStart(((sch.getCurPage() -1) * sch.getPageSize()) + 1);
		sch.setEnd(sch.getCurPage() * sch.getPageSize());
						
		// 초기 블록값 설정
		sch.setBlockSize(5);
		// block 설정
		int blocknum = (int)Math.ceil(sch.getCurPage() / (double)sch.getBlockSize());
		int endBlock = blocknum * sch.getBlockSize();
		sch.setEndBlock(endBlock > sch.getPageCount() ? sch.getPageCount() : endBlock);
		sch.setStartBlock(((blocknum - 1) * sch.getBlockSize()) + 1);
		
		return dao.tlist(sch);
	}
	
	public ArrayList<Project> getProject() {
		return dao.getProject();
	}
	
	public ArrayList<Task> ptlist(){
		return dao.ptlist();
	}
	public void insertTask(Task insert) {
		dao.insertTask(insert);
	}
	
	public void updateTask(Task upt) {
		dao.updateTask(upt);
	}
	
	public Task getTask (String task_co) {
		return dao.getTask(task_co);
	}
}
