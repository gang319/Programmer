package final_project.service;

import org.springframework.beans.factory.annotation.Autowired;

import final_project.vo.Member;
import final_project.dao.PersonAdDao;

public class PersonAdService {
	@Autowired
	private PersonAdDao dao;
	
	public Member adperson(Member m) {
		return dao.adperson(m);
	}
}
