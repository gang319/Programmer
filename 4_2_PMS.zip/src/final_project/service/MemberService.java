package final_project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.MemberDao;
import final_project.vo.Member;

@Service
public class MemberService {
	@Autowired
	private MemberDao dao;
	
	public Member memlogin(Member m) {
		return dao.memlogin(m);
	}
	
	public boolean loginChk(Member m) {
		Member mem = dao.memlogin(m);
		
		if(mem == null) {
			return false;
		}else {
			String passChk = mem.getPass();
			if(passChk.equals(m.getPass())) {
				return true;
			}else {
				return false;
			}
		}
	}

}
