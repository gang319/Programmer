package final_project.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import final_project.dao.MyWorkDao;
import final_project.vo.Issue;
import final_project.vo.Project;
import final_project.vo.Task;

@Service
public class MyWorkService {
	@Autowired
	private MyWorkDao dao;
	
	public ArrayList<Project> getProject(Project sch) {
		return dao.getProject(sch);
	}
	
	public ArrayList<Task> getTask(Task sch) {
		return dao.getTask(sch);
	}
	
	public ArrayList<Issue> getIssue(Issue sch) {
		return dao.getIssue(sch);
	}

}
