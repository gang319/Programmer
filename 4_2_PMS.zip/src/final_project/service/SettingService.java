package final_project.service;
//final_project.service.SettingService
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


import final_project.dao.SettingDao;
import final_project.vo.Member;
import final_project.vo.Search;

@Service
public class SettingService {
	@Autowired
	private SettingDao dao;
	
	public ArrayList<Member> elist(){
		/*
		PM 데이터 총건수 처리
		sch.setCount(dao.getCount(sch));
		
		//화면에 한번에 보여줄 데이터 수
		if(sch.getPageSize() == 0){sch.setPageSize(10);}
		
		//총 페이지 수 처리
		int pgCnt = (int)Math.ceil(sch.getCount()/(double)sch.getPageSize());
		
		//현재 클릭한 페이지 수 설정, 초기 값 1
		if(sch.getCurPage() == 0) { sch.setCurPage(1); }
		
		//next 클릭시, 전체 페이지 수를 넘지않게 처리
		if(sch.getCurPage()> sch.getPageCount()) {
			sch.setCurPage(sch.getPageCount());
		}
		
		//현재 클릭한 페이지 번호를 통해서 시작번호와 마지막 번호를 전송처리
		sch.setStart(((sch.getCurPage()-1) * sch.getPageSize()) + 1);
		sch.setEnd(sch.getCurPage() * sch.getPageSize());
		
		//초기 블록값 설정
		sch.setBlockSize(5);
		
		//block 설정
		int blocknum = (int)Math.ceil(sch.getCurPage() / (double)sch.getBlockSize());
		int endBlock = blocknum * sch.getBlockSize();
		sch.setEndBlock(endBlock > sch.getPageCount() ? sch.getPageCount() : endBlock);
		sch.setStartBlock(((blocknum - 1) * sch.getBlockSize()) +1 );
		
		return dao.elist(sch);
		*/
		
		return dao.elist();
	}
	
	public ArrayList<Member> clist(){
		return dao.clist();
	}
	
	public void insertMember(Member insert) {
		dao.insertMember(insert);
	}
	
	/*public Member getMember(String id);*/
	public Member getMember(String id) {
		
		return dao.getMember(id);	
	}
	
	@Value("${upload}")
	private String upload;
	@Value("${tmpupload}")
	private String tmpupload;
	
	/*public void updateMember(Member upt);*/
	public void updateMember(Member upt) {
		dao.updateMember(upt);
	}
	
	/*public void delMember(String id);*/
	public void delMember(String id) {
		dao.delMember(id);
	}
	
	/*public void adMember(Member ad); */
	public void adMember(Member ad) {
		dao.adMember(ad);
	}
	
	/*public void pmMember(Member pm); */
	public void pmMember(Member pm) {
		dao.pmMember(pm);
	}
	
	
	
}