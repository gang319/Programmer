package final_project.vo;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class Issue {
	private boolean nw;
	private int no;
	private int refno;
	private int level;
	
	private String issue_co;
	private String mem_co;
	private String title;
	private String name;
	private String manager;
	private String content;
	private Date ins_date;
	private String issue_sts;
	private String important;
	
	private MultipartFile report;
	private String file_name;
	private String org_name;
	
	public Issue() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Issue(String issue_co, String mem_co, String title, String name, String manager, String content,
			Date ins_date, String issue_sts, String important) {
		super();
		this.issue_co = issue_co;
		this.mem_co = mem_co;
		this.title = title;
		this.name = name;
		this.manager = manager;
		this.content = content;
		this.ins_date = ins_date;
		this.issue_sts = issue_sts;
		this.important = important;
	}

	public Issue(int no, int refno, String issue_co, String mem_co, String title, String name, String manager,
			String content, Date ins_date, String issue_sts, String important) {
		super();
		this.no = no;
		this.refno = refno;
		this.issue_co = issue_co;
		this.mem_co = mem_co;
		this.title = title;
		this.name = name;
		this.manager = manager;
		this.content = content;
		this.ins_date = ins_date;
		this.issue_sts = issue_sts;
		this.important = important;
	}

	public boolean isNw() {
		return nw;
	}

	public void setNw(boolean nw) {
		this.nw = nw;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getRefno() {
		return refno;
	}

	public void setRefno(int refno) {
		this.refno = refno;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getIssue_co() {
		return issue_co;
	}

	public void setIssue_co(String issue_co) {
		this.issue_co = issue_co;
	}

	public String getMem_co() {
		return mem_co;
	}

	public void setMem_co(String mem_co) {
		this.mem_co = mem_co;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getIns_date() {
		return ins_date;
	}

	public void setIns_date(Date ins_date) {
		this.ins_date = ins_date;
	}

	public String getIssue_sts() {
		return issue_sts;
	}

	public void setIssue_sts(String issue_sts) {
		this.issue_sts = issue_sts;
	}

	public String getImportant() {
		return important;
	}

	public void setImportant(String important) {
		this.important = important;
	}

	public MultipartFile getReport() {
		return report;
	}

	public void setReport(MultipartFile report) {
		this.report = report;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getOrg_name() {
		return org_name;
	}

	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}
	
}
