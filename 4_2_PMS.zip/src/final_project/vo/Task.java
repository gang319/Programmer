package final_project.vo;

import java.util.Date;

public class Task {
	private String task_co;
	private String mem_co;	
	private String pro_co;
	private String pro_title;
	private String task_name;
	private String pro_state;
	private String pro_statenum;	
	private String sort;
	private int task_rank;
	private String difficulty;
	private Date task_sdate;
	private Date deadline;
	private String name;
	
	public String getTask_co() {
		return task_co;
	}
	public void setTask_co(String task_co) {
		this.task_co = task_co;
	}
	public String getMem_co() {
		return mem_co;
	}
	public void setMem_co(String mem_co) {
		this.mem_co = mem_co;
	}
	public String getPro_co() {
		return pro_co;
	}
	public void setPro_co(String pro_co) {
		this.pro_co = pro_co;
	}
	public String getTask_name() {
		return task_name;
	}
	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	public String getPro_state() {
		return pro_state;
	}
	public void setPro_state(String pro_state) {
		this.pro_state = pro_state;
	}
	public String getPro_statenum() {
		return pro_statenum;
	}
	public void setPro_statenum(String pro_statenum) {
		this.pro_statenum = pro_statenum;
	}
	public String getSort() {
		return sort;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public int getTask_rank() {
		return task_rank;
	}
	public void setTask_rank(int task_rank) {
		this.task_rank = task_rank;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public Date getTask_sdate() {
		return task_sdate;
	}
	public void setTask_sdate(Date task_sdate) {
		this.task_sdate = task_sdate;
	}
	public Date getDeadline() {
		return deadline;
	}
	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Task(String task_co, String mem_co, String pro_co, String task_name, String pro_state, String pro_statenum,
			String sort, int task_rank, String difficulty, Date task_sdate, Date deadline, String name) {
		super();
		this.task_co = task_co;
		this.mem_co = mem_co;
		this.pro_co = pro_co;
		this.task_name = task_name;
		this.pro_state = pro_state;
		this.pro_statenum = pro_statenum;
		this.sort = sort;
		this.task_rank = task_rank;
		this.difficulty = difficulty;
		this.task_sdate = task_sdate;
		this.deadline = deadline;
		this.name = name;
	}
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Task(String task_name, String pro_state, String sort, int task_rank, Date deadline, String name) {
		super();
		this.task_name = task_name;
		this.pro_state = pro_state;
		this.sort = sort;
		this.task_rank = task_rank;
		this.deadline = deadline;
		this.name = name;
	}
	public String getPro_title() {
		return pro_title;
	}
	public void setPro_title(String pro_title) {
		this.pro_title = pro_title;
	}
	
}
