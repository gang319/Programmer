package final_project.vo;

public class Att_File {
	private String file_co;
	private String issue_co;
	private String file_name;
	private String org_name;
	
	public Att_File() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Att_File(String file_co, String issue_co, String file_name, String org_name) {
		super();
		this.file_co = file_co;
		this.issue_co = issue_co;
		this.file_name = file_name;
		this.org_name = org_name;
	}
	
	public Att_File(String file_co, String issue_co, String file_name) {
		super();
		this.file_co = file_co;
		this.issue_co = issue_co;
		this.file_name = file_name;
	}
	
	public Att_File(String file_name, String org_name) {
		super();
		this.file_name = file_name;
		this.org_name = org_name;
	}

	public String getFile_co() {
		return file_co;
	}

	public void setFile_co(String file_co) {
		this.file_co = file_co;
	}

	public String getIssue_co() {
		return issue_co;
	}

	public void setIssue_co(String issue_co) {
		this.issue_co = issue_co;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public String getOrg_name() {
		return org_name;
	}

	public void setOrg_name(String org_name) {
		this.org_name = org_name;
	}

}
