package final_project.vo;

import java.util.Date;

public class Project {
	private String pro_co;
	private String pro_title;
	private Date pro_date;
	private Date last_date;
	private int pro_gress;
	private String mem_co;
	private String name;
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Project(String pro_co, String pro_title, Date pro_date, Date last_date, int pro_gress, String name) {
		super();
		this.pro_co = pro_co;
		this.pro_title = pro_title;
		this.pro_date = pro_date;
		this.last_date = last_date;
		this.pro_gress = pro_gress;
		this.name = name;
	}
	public Project(String pro_co, String pro_title, Date pro_date, Date last_date, int pro_gress, String mem_co,
			String name) {
		super();
		this.pro_co = pro_co;
		this.pro_title = pro_title;
		this.pro_date = pro_date;
		this.last_date = last_date;
		this.pro_gress = pro_gress;
		this.mem_co = mem_co;
		this.name = name;
	}
	public String getPro_co() {
		return pro_co;
	}
	public void setPro_co(String pro_co) {
		this.pro_co = pro_co;
	}
	public String getPro_title() {
		return pro_title;
	}
	public void setPro_title(String pro_title) {
		this.pro_title = pro_title;
	}
	public Date getPro_date() {
		return pro_date;
	}
	public void setPro_date(Date pro_date) {
		this.pro_date = pro_date;
	}
	public Date getLast_date() {
		return last_date;
	}
	public void setLast_date(Date last_date) {
		this.last_date = last_date;
	}
	public int getPro_gress() {
		return pro_gress;
	}
	public void setPro_gress(int pro_gress) {
		this.pro_gress = pro_gress;
	}
	public String getMem_co() {
		return mem_co;
	}
	public void setMem_co(String mem_co) {
		this.mem_co = mem_co;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
