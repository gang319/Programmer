package final_project.vo;

public class Member {
	private String mem_co;
	private String mem_sort;
	private String id;
	private String pass;
	private String name;
	private String job;
	private String phone;
	private String email;
	private String photo;
	private String admin_ck;
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Member(String mem_co, String mem_sort, String id, String pass, String name, String job, String phone,
			String email) {
		super();
		this.mem_co = mem_co;
		this.mem_sort = mem_sort;
		this.id = id;
		this.pass = pass;
		this.name = name;
		this.job = job;
		this.phone = phone;
		this.email = email;
	}
	
	public Member(String mem_co, String mem_sort, String id, String pass, String name, String job, String phone,
			String photo, String admin_ck) {
		super();
		this.mem_co = mem_co;
		this.mem_sort = mem_sort;
		this.id = id;
		this.pass = pass;
		this.name = name;
		this.job = job;
		this.phone = phone;
		this.photo = photo;
		this.admin_ck = admin_ck;
	}
	
	
	
	public Member(String mem_co, String mem_sort, String id, String pass, String name, String job, String phone,
			String email, String photo, String admin_ck) {
		super();
		this.mem_co = mem_co;
		this.mem_sort = mem_sort;
		this.id = id;
		this.pass = pass;
		this.name = name;
		this.job = job;
		this.phone = phone;
		this.email = email;
		this.photo = photo;
		this.admin_ck = admin_ck;
	}

	public String getMem_co() {
		return mem_co;
	}

	public void setMem_co(String mem_co) {
		this.mem_co = mem_co;
	}

	public String getMem_sort() {
		return mem_sort;
	}

	public void setMem_sort(String mem_sort) {
		this.mem_sort = mem_sort;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getAdmin_ck() {
		return admin_ck;
	}

	public void setAdmin_ck(String admin_ck) {
		this.admin_ck = admin_ck;
	}
}
