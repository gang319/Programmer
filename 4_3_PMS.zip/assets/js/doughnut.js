	Chart.pluginService.register({
		beforeDraw: function (chart) {
		if (chart.config.options.elements.center) {
        //문자열에서 ctx가져오기
        var ctx = chart.chart.ctx;
        
		//옵션의 가운데 객체에서 옵션 가져오기
        var centerConfig = chart.config.options.elements.center;
      	var fontStyle = centerConfig.fontStyle || 'Arial';
		var txt = centerConfig.text;
        var color = centerConfig.color || '#000';
        var sidePadding = centerConfig.sidePadding || 20;
        var sidePaddingCalculated = (sidePadding/100) * (chart.innerRadius * 2)
        
		//30px의 기본글꼴로 시작
        ctx.font = "30px " + fontStyle;
        
		//문자열의 너비와 10을 뺀 요소의 너비를 가져와서 5px 사이드패딩을 제공하십시오.
        var stringWidth = ctx.measureText(txt).width;
        var elementWidth = (chart.innerRadius * 2) - sidePaddingCalculated;

        // 글꼴이 얼마나 커질 수 있는지 알아보자
        var widthRatio = elementWidth / stringWidth;
        var newFontSize = Math.floor(30 * widthRatio);
        var elementHeight = (chart.innerRadius * 2);

        // 새 글꼴 크기를 선택하여 레이블 높이보다 크지않도록 합니다.
        var fontSizeToUse = Math.min(newFontSize, elementHeight);

		//글꼴 설정을 올바르게 그립니다.
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        var centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
        var centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);
        ctx.font = fontSizeToUse+"px " + fontStyle;
        ctx.fillStyle = color;
        
        //중앙에 텍스트 그리기
        ctx.fillText(txt, centerX, centerY);
			}
		}
	});
		// 차트 값,중앙 text
		var a=70;
		var config = {
			type: 'doughnut',
			data: {
				labels: [
				  "전체프로젝트",
				  ""
				],
				datasets: [{
					data: [a, 100-a],
					backgroundColor: [
					  "#6B66FF",
					  "#EAEAEA"
					],
					hoverBackgroundColor: [
					  "#6B66FF",
					  "#EAEAEA"
					]
				}]
			},
		options: {
			elements: {
				center: {
					text: a+'%',
          color: '#6B66FF', // 기본값 : #000000
          fontStyle: 'Arial', // 기본값 : Arial
          sidePadding: 20 // Defualt는 20(백분율)입니다.
				}
			}
		}
	};

		var ctx = document.getElementById("myChart").getContext("2d");
		var myChart = new Chart(ctx, config);